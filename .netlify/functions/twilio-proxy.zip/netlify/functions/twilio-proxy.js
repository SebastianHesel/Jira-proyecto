var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/twilio-proxy.js
var twilio_proxy_exports = {};
__export(twilio_proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(twilio_proxy_exports);
var CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "authorization,content-type,accept"
};
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS, body: "" };
  }
  try {
    const original = new URL(event.rawUrl);
    const apiPath = original.pathname.replace(/^\/api\/twilio/, "") || "/";
    const targetUrl = `https://api.twilio.com${apiPath}${original.search}`;
    const forwardHeaders = { ...event.headers };
    delete forwardHeaders["host"];
    delete forwardHeaders["origin"];
    delete forwardHeaders["referer"];
    delete forwardHeaders["x-forwarded-for"];
    delete forwardHeaders["x-forwarded-host"];
    delete forwardHeaders["x-forwarded-proto"];
    delete forwardHeaders["x-nf-request-id"];
    delete forwardHeaders["cdn-loop"];
    delete forwardHeaders["via"];
    forwardHeaders["host"] = "api.twilio.com";
    const fetchOptions = {
      method: event.httpMethod,
      headers: forwardHeaders
    };
    if (event.body && event.httpMethod !== "GET" && event.httpMethod !== "HEAD") {
      fetchOptions.body = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf-8") : event.body;
    }
    const response = await fetch(targetUrl, fetchOptions);
    const body = await response.text();
    return {
      statusCode: response.status,
      headers: { "content-type": response.headers.get("content-type") || "application/json", ...CORS },
      body
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: { "content-type": "application/json", ...CORS },
      body: JSON.stringify({ error: "Twilio proxy error", detail: err.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
